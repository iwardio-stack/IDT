package com.idt.installation;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button newReport = findViewById(R.id.newReport);
        Button existingReport = findViewById(R.id.existingReport);

        newReport.setOnClickListener(v -> {
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra("new_report", true);
            startActivity(i);
        });

        existingReport.setOnClickListener(v -> {
            Intent i = new Intent(this, ReportsActivity.class);
            startActivity(i);
        });
    }
}
