package com.idt.installation;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class ReportsActivity extends AppCompatActivity {
    LinearLayout list;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_reports);
        list = findViewById(R.id.reportList);
        findViewById(R.id.backHome).setOnClickListener(v -> finish());
        refresh();
    }
    void refresh() {
        list.removeAllViews();
        boolean saved = getSharedPreferences("idt_reports", MODE_PRIVATE).getBoolean("has_report", false);
        if (!saved) {
            TextView empty = new TextView(this);
            empty.setText("No saved reports yet. Create a New Report first.");
            empty.setTextColor(0xFFFFFFFF); empty.setTextSize(16); empty.setPadding(16,24,16,24);
            list.addView(empty); return;
        }
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(18,18,18,18); card.setBackgroundColor(0xFF202020);
        TextView title = new TextView(this); title.setText("Saved Installation Report"); title.setTextColor(0xFFB7FF00); title.setTextSize(18); title.setTypeface(null,1);
        TextView detail = new TextView(this); detail.setText("Tap Open to continue editing this report"); detail.setTextColor(0xFFFFFFFF); detail.setPadding(0,8,0,12);
        Button open = new Button(this); open.setText("OPEN REPORT");
        Button delete = new Button(this); delete.setText("DELETE REPORT");
        open.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class).putExtra("new_report", false)));
        delete.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Delete report?").setMessage("This removes the saved report from this device.").setNegativeButton("Cancel", null).setPositiveButton("Delete", (d,w) -> { getSharedPreferences("idt_reports", MODE_PRIVATE).edit().clear().apply(); refresh(); }).show());
        card.addView(title); card.addView(detail); card.addView(open); card.addView(delete); list.addView(card);
    }
    @Override protected void onResume() { super.onResume(); if (list != null) refresh(); }
}
