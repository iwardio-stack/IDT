package com.idt.installation;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    EditText job,date,client,address,contact,installer,defects,notes;
    CheckBox accepted,conditional;
    SignatureView clientSignature,installerSignature;
    LinearLayout itemsContainer, photoContainer;
    static class ItemRow { EditText item, description, status, quality; }
    ArrayList<ItemRow> itemFields = new ArrayList<>();
    ArrayList<Uri> photos = new ArrayList<>();
    File lastPdf;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        if (getIntent().getBooleanExtra("new_report", false)) getPreferences(0).edit().clear().apply();
        job=findViewById(R.id.job); date=findViewById(R.id.date); client=findViewById(R.id.client);
        address=findViewById(R.id.address); contact=findViewById(R.id.contact); installer=findViewById(R.id.installer);
        defects=findViewById(R.id.defects); notes=findViewById(R.id.notes);
        accepted=findViewById(R.id.accepted); conditional=findViewById(R.id.conditional);
        clientSignature=findViewById(R.id.clientSignature); installerSignature=findViewById(R.id.installerSignature);
        itemsContainer=findViewById(R.id.itemsContainer); photoContainer=findViewById(R.id.photoContainer);
        date.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        for(int i=1;i<=10;i++) addItemField(i);
        findViewById(R.id.clearClient).setOnClickListener(v->clientSignature.clear());
        findViewById(R.id.clearInstaller).setOnClickListener(v->installerSignature.clear());
        clientSignature.setOnClickListener(v->openSignatureDialog("Client Signature", clientSignature));
        installerSignature.setOnClickListener(v->openSignatureDialog("Installer Signature", installerSignature));
        findViewById(R.id.addPhoto).setOnClickListener(v->choosePhoto());
        findViewById(R.id.save).setOnClickListener(v->{saveForm(); Toast.makeText(this,"Form saved",Toast.LENGTH_SHORT).show();});
        findViewById(R.id.pdf).setOnClickListener(v->{lastPdf=createPdf(); if(lastPdf!=null)Toast.makeText(this,"PDF report created",Toast.LENGTH_SHORT).show();});
        findViewById(R.id.share).setOnClickListener(v->{if(lastPdf==null)lastPdf=createPdf(); sharePdf(lastPdf);});
        loadForm();
    }

    EditText makeItemEdit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.LTGRAY);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(183,255,0)));
        e.setPadding(10, 6, 10, 6); e.setSingleLine(false);
        e.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return e;
    }

    void addItemField(int n) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding(12, 12, 12, 12);
        block.setBackgroundColor(Color.rgb(32,32,32));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.setMargins(0, 8, 0, 8); itemsContainer.addView(block, bp);

        TextView title = new TextView(this);
        title.setText("ITEM " + n); title.setTextColor(Color.rgb(255,122,0));
        title.setTextSize(15); title.setTypeface(Typeface.DEFAULT_BOLD);
        block.addView(title);

        ItemRow row = new ItemRow();
        row.item = makeItemEdit("Item"); row.description = makeItemEdit("Description");
        row.status = makeItemEdit("Status"); row.quality = makeItemEdit("Quality");
        block.addView(row.item); block.addView(row.description);
        LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
        line.addView(row.status); line.addView(row.quality); block.addView(line);
        itemFields.add(row);
    }


    void openSignatureDialog(String title, SignatureView target) {
        final Dialog dialog = new Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,24,24,24);
        TextView heading = new TextView(this); heading.setText(title); heading.setTextSize(20); heading.setTextColor(Color.BLACK);
        box.addView(heading);
        SignatureView pad = new SignatureView(this, null);
        pad.setLayoutParams(new LinearLayout.LayoutParams(-1, 420)); box.addView(pad);
        LinearLayout actions = new LinearLayout(this); actions.setGravity(Gravity.END);
        Button clear = new Button(this); clear.setText("Clear");
        Button save = new Button(this); save.setText("Save & Lock");
        Button cancel = new Button(this); cancel.setText("Cancel");
        actions.addView(clear); actions.addView(cancel); actions.addView(save); box.addView(actions);
        clear.setOnClickListener(v->pad.clear());
        cancel.setOnClickListener(v->dialog.dismiss());
        save.setOnClickListener(v->{ target.setBitmap(pad.getBitmap()); target.setLocked(true); dialog.dismiss(); Toast.makeText(this,"Signature saved and locked",Toast.LENGTH_SHORT).show(); });
        dialog.setContentView(box); Window w=dialog.getWindow(); if(w!=null)w.setLayout(-1,-2); dialog.show();
    }

    void choosePhoto() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,44);
    }

    @Override protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d);
        if(r==44 && c==RESULT_OK && d!=null) {
            if(d.getClipData()!=null) {
                for(int i=0;i<d.getClipData().getItemCount();i++) addPhoto(d.getClipData().getItemAt(i).getUri());
            } else if(d.getData()!=null) addPhoto(d.getData());
        }
    }

    void addPhoto(Uri u) {
        photos.add(u);
        ImageView v=new ImageView(this); v.setImageURI(u); v.setAdjustViewBounds(true);
        photoContainer.addView(v,new LinearLayout.LayoutParams(-1,260));
    }

    String val(EditText e){return e.getText().toString();}
    void saveForm() {
        android.content.SharedPreferences.Editor x=getPreferences(0).edit();
        x.putString("job",val(job)).putString("date",val(date)).putString("client",val(client))
        .putString("address",val(address)).putString("contact",val(contact)).putString("installer",val(installer))
        .putString("defects",val(defects)).putString("notes",val(notes))
        .putBoolean("accepted",accepted.isChecked()).putBoolean("conditional",conditional.isChecked());
        for(int i=0;i<itemFields.size();i++) { ItemRow r=itemFields.get(i); x.putString("item"+i,val(r.item)).putString("desc"+i,val(r.description)).putString("status"+i,val(r.status)).putString("quality"+i,val(r.quality)); }
        x.apply();
        getSharedPreferences("idt_reports", MODE_PRIVATE).edit().putBoolean("has_report", true).apply();
    }

    void loadForm() {
        android.content.SharedPreferences p=getPreferences(0);
        job.setText(p.getString("job","")); date.setText(p.getString("date",date.getText().toString()));
        client.setText(p.getString("client","")); address.setText(p.getString("address",""));
        contact.setText(p.getString("contact","")); installer.setText(p.getString("installer",""));
        defects.setText(p.getString("defects","")); notes.setText(p.getString("notes",""));
        accepted.setChecked(p.getBoolean("accepted",false)); conditional.setChecked(p.getBoolean("conditional",false));
        for(int i=0;i<itemFields.size();i++) { ItemRow r=itemFields.get(i); r.item.setText(p.getString("item"+i,"")); r.description.setText(p.getString("desc"+i,"")); r.status.setText(p.getString("status"+i,"")); r.quality.setText(p.getString("quality"+i,"")); }
    }

    File createPdf() {
        saveForm();
        PdfDocument doc=new PdfDocument();
        int pageNo=1;
        PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo++).create());
        Canvas c=page.getCanvas(); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK); p.setTextSize(12);
        int y=35;
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(16);
        c.drawText("I.D.T. STEELWORKS AND ENGINEERING",30,y,p); y+=22;
        p.setTextSize(12); c.drawText("Unit 7, Concert Park, Joe Mark's Boulevard, Retreat",30,y,p); y+=17;
        c.drawText("0645558411 | iwardio@idtsteelwork.co.za",30,y,p); y+=25;
        p.setTextSize(14); c.drawText("CLIENT INSTALLATION SIGN-OFF",30,y,p); y+=28;
        p.setTypeface(Typeface.DEFAULT);
        String[][] rows={{"Job",val(job)},{"Date",val(date)},{"Client",val(client)},{"Address",val(address)},{"Contact",val(contact)},{"Installer",val(installer)}};
        for(String[] row:rows){y=drawWrapped(c,row[0]+": "+row[1],30,y,p,535);y+=5;}
        y+=8; p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Installation items",30,y,p); y+=18; p.setTypeface(Typeface.DEFAULT);
        for(int i=0;i<itemFields.size();i++){ItemRow r=itemFields.get(i); String line=(i+1)+". "+val(r.item)+" | "+val(r.description)+" | Status: "+val(r.status)+" | Quality: "+val(r.quality); y=drawWrapped(c,line,35,y,p,525);y+=3;if(y>735){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo++).create());c=page.getCanvas();y=35;}}
        y=drawWrapped(c,"Outstanding items / defects: "+val(defects),30,y+8,p,535);
        y=drawWrapped(c,"Notes: "+val(notes),30,y+5,p,535);
        y+=12; c.drawText("Accepted: "+(accepted.isChecked()?"YES":"NO")+"   Conditional: "+(conditional.isChecked()?"YES":"NO"),30,y,p); y+=18;
        p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Client Signature",30,y,p); c.drawText("Installer Signature",315,y,p);
        p.setTypeface(Typeface.DEFAULT);
        c.drawBitmap(clientSignature.getBitmap(),null,new Rect(30,y+8,280,y+100),p);
        c.drawBitmap(installerSignature.getBitmap(),null,new Rect(315,y+8,565,y+100),p);
        doc.finishPage(page);

        // Compact photo pages: 2 columns x 5 rows (10 photos per page).
        for(int base=0; base<photos.size(); base+=10) {
            PdfDocument.Page photoPage=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo++).create());
            Canvas pc=photoPage.getCanvas(); Paint pp=new Paint(Paint.ANTI_ALIAS_FLAG);
            pc.drawColor(Color.WHITE); pp.setColor(Color.BLACK); pp.setTextSize(12);
            pp.setTypeface(Typeface.DEFAULT_BOLD); pc.drawText("IDT Installation Photos",30,24,pp);
            pp.setTypeface(Typeface.DEFAULT);
            int cellW=255, cellH=145, gapX=25, gapY=8, left=30, top=35;
            for(int j=0;j<10 && base+j<photos.size();j++) {
                try {
                    Bitmap b=MediaStore.Images.Media.getBitmap(getContentResolver(),photos.get(base+j));
                    int col=j%2, row=j/2;
                    int x=left+col*(cellW+gapX), y0=top+row*(cellH+gapY);
                    pp.setStyle(Paint.Style.STROKE); pc.drawRect(x,y0,x+cellW,y0+cellH,pp);
                    pc.drawBitmap(b,null,fitRect(b,x+4,y0+4,x+cellW-4,y0+cellH-18),pp);
                    pp.setStyle(Paint.Style.FILL); pp.setTextSize(9);
                    pc.drawText("Photo "+(base+j+1),x+5,y0+cellH-5,pp);
                } catch(Exception ignored) {}
            }
            doc.finishPage(photoPage);
        }
        try {
            File f=new File(getCacheDir(),"IDT_Signoff_"+System.currentTimeMillis()+".pdf");
            FileOutputStream out=new FileOutputStream(f); doc.writeTo(out); out.close(); doc.close(); return f;
        } catch(Exception e){doc.close(); Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show(); return null;}
    }

    Rect fitRect(Bitmap b,int left,int top,int right,int bottom) {
        float scale=Math.min((right-left)/(float)b.getWidth(),(bottom-top)/(float)b.getHeight());
        int w=(int)(b.getWidth()*scale), h=(int)(b.getHeight()*scale);
        int x=left+(right-left-w)/2, y=top+(bottom-top-h)/2;
        return new Rect(x,y,x+w,y+h);
    }

    int drawWrapped(Canvas c,String s,float x,int y,Paint p,int max) {
        String[] words=s.split("\\s+"); String line="";
        for(String w:words){if(p.measureText(line+w)>max){c.drawText(line,x,y,p);y+=16;line="";}line+=w+" ";}
        c.drawText(line,x,y,p); return y+16;
    }

    void sharePdf(File f) {
        if(f==null)return;
        Uri u=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_SUBJECT,"IDT Installation Sign-Off");
        i.putExtra(Intent.EXTRA_TEXT,"Please find attached the IDT installation sign-off report.");
        i.putExtra(Intent.EXTRA_STREAM,u); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i,"Share PDF report via WhatsApp or email"));
    }
}