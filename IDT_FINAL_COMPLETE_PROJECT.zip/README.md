# IDT Installation Sign-Off Android App

Features included: home page, new/existing reports, item blocks, signature dialog/lock, photo capture, compact PDF photo grid, and sharing.

Build in GitHub Actions using the included workflow. The workflow uses Gradle 8.9 and Java 17.
